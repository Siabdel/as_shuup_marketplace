# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2021, Shuup Commerce Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.

CAMPAIGNS_CACHE_NAMESPACE = "shuup_campaigns"
CONTEXT_CONDITION_CACHE_NAMESPACE = "shuup_context_conditions"
CATALOG_FILTER_CACHE_NAMESPACE = "shuup_catalog_filters"
